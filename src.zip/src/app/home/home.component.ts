import { Component, OnInit, ViewChild } from '@angular/core';
import {
  ChartComponent,
  ApexAxisChartSeries,
  ApexChart,
  ApexXAxis,
  ApexTitleSubtitle,
  ApexDataLabels,
  ApexPlotOptions,
  ApexNonAxisChartSeries,
  ApexResponsive
} from "ng-apexcharts";
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

// for mat table employee
export interface UserData {
  id: any;
  name: string;
  email: string;
  address: string;
  contact_no:any;
  degination:string;
  start_date:any;
}
// mat table for Product
declare var $: any;
export interface UserData1 {
  id: any;
  name: string;
  weigth: number;
  item_no: number;
  price:number;
  valid_to:Date;
  valid_upto:any;
}
// mat table for Customer
export interface UserData3 {
  id: any;
  name: string;
  email: string;
  address: string;
  contact_no:any;
  dob:Date;
  start_date:any;
}

// for chart
export type ChartOptions = {
  series: ApexAxisChartSeries;
  chart: ApexChart;
  xaxis: ApexXAxis;
  title: ApexTitleSubtitle;
};
export type ChartOptions1 = {
  title: ApexTitleSubtitle;
  series: ApexAxisChartSeries;
  chart: ApexChart;
  dataLabels: ApexDataLabels;
  plotOptions: ApexPlotOptions;
  xaxis: ApexXAxis;
};
export type ChartOptions2 = {
  title: ApexTitleSubtitle;
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  responsive: ApexResponsive[];
  labels: any;
};

const ELEMENT_DATA: UserData[] = [
  {id: 1, name: 'Hydrogen', email: 'nbsjsja', address: 'snns',contact_no:'98155',degination:'sa',start_date:'1254'},
  
  
];

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  show = true;
  Obj:any = {}
  // for mat table employee
  displayedColumns: string[] = ['id', 'name', 'email', 'address','contact_no','degination','start_date','action'];
  dataSource: MatTableDataSource<UserData>;
// for mat table employee
  displayedColumns1: string[] = ['id', 'name', 'weigth', 'item_no','price','valid_to','valid_upto','action'];
  dataSource1: MatTableDataSource<UserData1>;
// mat table for Customer
  displayedColumns2: string[] = ['id', 'name', 'email', 'address','contact_no','dob','start_date','action'];
  dataSource2: MatTableDataSource<UserData3>;
  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  //  for chart
  @ViewChild("chart")
  chart: ChartComponent = new ChartComponent;
  public chartOptions: any;

  public chartOptions2: any;
  public chartOptions1: any;

  
  constructor() {
    this.dataSource = new MatTableDataSource();
    this.dataSource1 = new MatTableDataSource();
    this.dataSource2 = new MatTableDataSource();
    
// for chart
    this.chartOptions = {
      series: [
        {
          name: "My-series",
          data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
        }
      ],
      chart: {
        height: 350,
        type: "bar"
      },
      title: {
        text: "Product"
      },
      xaxis: {
        categories: ["Jan", "Feb",  "Mar",  "Apr",  "May",  "Jun",  "Jul",  "Aug", "Sep"]
      }
    };
    
    this.chartOptions1= {
      title: {
        text: "Customer"
      },
      series: [
        {
          name: "basic",
          data: [400, 430, 448, 470, 540, 580, 690, 1100, 1200, 1380]
        }
      ],
      chart: {
        type: "bar",
        height: 350
      },
      plotOptions: {
        bar: {
          horizontal: true
        }
      },
      dataLabels: {
        enabled: false
      },
      xaxis: {
        categories: [
          "South Korea",
          "Canada",
          "United Kingdom",
          "Netherlands",
          "Italy",
          "France",
          "Japan",
          "United States",
          "China",
          "Germany"
        ]
      }
    };
    this.chartOptions2 = {
      title: {
        text: "Employee"
      },
      series: [44, 55, 13, 43, 22],
      chart: {
        type: "donut"
      },
      labels: ["Team A", "Team B", "Team C", "Team D", "Team E"],
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: "bottom"
            }
          }
        }
      ]
    };
  }

  ngOnInit(): void {
    this.Obj['c1'] = 0
    
    this.Obj['c2'] = 0
    this.Obj['c3'] = 0
  }

  modalOpen(i: number) {
    if (i == 1) {
     
      $('#myModal1').modal('show');
      $("#myModal1").appendTo("body");
    }
    if (i == 2) {
      $('#myModal2').modal('show');
      $("#myModal2").appendTo("body");
    }
    if (i == 3) {
      $('#myModal3').modal('show');
      $("#myModal3").appendTo("body");
    }
    if (i == 4) {
      $('#myModal4').modal('show');
      $("#myModal4").appendTo("body");
    }

  }
//  for mat table
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.dataSource1.paginator = this.paginator;
    this.dataSource1.sort = this.sort;
    this.dataSource2.paginator = this.paginator;
    this.dataSource2.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    this.dataSource1.filter = filterValue.trim().toLowerCase();
    this.dataSource2.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator &&this.dataSource1.paginator&&this.dataSource2.paginator) {
      this.dataSource.paginator.firstPage();
      this.dataSource1.paginator.firstPage();
      this.dataSource2.paginator.firstPage();
    }
  }

}
