import { Component, OnInit } from '@angular/core';
import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

export interface UserData {
  id: string;
  name: string;
  email: string;
  address: string;
  contact_no:any;
  dob:Date;
  start_date:any;
}
declare var $: any;
@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  displayedColumns: string[] = ['id', 'name', 'email', 'address','contact_no','dob','start_date','action'];
  dataSource: MatTableDataSource<UserData>;

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort)
  sort!: MatSort;

  constructor() {
    // Create 100 users
    

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource();
   }

  ngOnInit(): void {
  }
  
  modalOpen(i: number) {
    if (i == 1) {
     
      $('#myModal1').modal('show');
    }
    if (i == 2) {
      $('#myModal2').modal('show');
    }
    if (i == 3) {
      $('#myModal3').modal('show');
    }
    if (i == 4) {
      $('#myModal4').modal('show');
    }

  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
