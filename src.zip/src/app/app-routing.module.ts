import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login/login.component';
import { NavComponent } from './nav/nav.component';
import { EmployeeComponent } from './employee/employee.component';
import { ProductComponent } from './product/product.component';
import { CustomerComponent } from './customer/customer.component';
import { HomeComponent } from './home/home.component';
const routes: Routes = [{ path: '', redirectTo: 'index', pathMatch: 'full' }
                        ,{path:'index',component:LoginComponent},
                          {path:'index/nav',component:NavComponent,

children:[{ path: '', redirectTo: 'home', pathMatch: 'full' },
          {path:'home',component:HomeComponent},
          {path:'employee',component:EmployeeComponent},
          {path:'product',component:ProductComponent},
          {path:'customer',component:CustomerComponent}]
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
